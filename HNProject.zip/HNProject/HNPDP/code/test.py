import pandas as pd
file_path="data2.xlsx"


interaction_matrix = pd.read_excel(file_path, header=None)
print(interaction_matrix.shape)